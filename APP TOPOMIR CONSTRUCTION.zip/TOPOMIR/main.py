import webview
import os
import sys
import base64

class Api:
    def save_file(self, content, filename):
        try:
            result = window.create_file_dialog(
                webview.SAVE_DIALOG, 
                save_filename=filename
            )
            
            if result:
                file_path = result if isinstance(result, str) else result[0]
                
                # CORREÇÃO: Tratamento universal para qualquer tipo de arquivo
                try:
                    # Tenta decodificar como base64 primeiro
                    file_content = base64.b64decode(content, validate=True)
                    with open(file_path, 'wb') as f:
                        f.write(file_content)
                except:
                    # Se não for base64 válido, salva como texto
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(content)
                
                return True
            return False
        except Exception as e:
            print(f"Erro ao salvar arquivo: {e}")
            return False

def get_path():
    if getattr(sys, 'frozen', False):
        return os.path.join(sys._MEIPASS, 'index.html')
    return os.path.abspath('index.html')

if __name__ == '__main__':
    api = Api()
    window = webview.create_window(
        'TOPOMIR CONSTRUCTION', 
        get_path(), 
        width=1200, 
        height=800,
        js_api=api,
        resizable=True
    )
    webview.start()